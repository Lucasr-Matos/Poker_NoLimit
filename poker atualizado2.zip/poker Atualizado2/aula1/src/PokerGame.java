import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//importações

public class PokerGame {
    private List<Jogador> jogadores;
    private Baralho baralho;
    private int pot;
    private int apostaAtual;
    private int BB;
    private int SB;
    private List<Jogador> jogadoresInativos;

    public PokerGame() {// método construtor
        jogadores = new ArrayList<>();
        jogadoresInativos = new ArrayList<>();
        baralho = new Baralho();
        pot = 0;
        apostaAtual = 10; // Valor inicial do big blind
        BB = 0;
        SB = 4; // Índice do small blind na lista de jogadores
    }

    public void adicionarJogador(Jogador jogador) {// adiciona um jogador a rodada
        jogadores.add(jogador);
    }

    public void distribuirCartas() {// distribui as maos de cada jogador
        for (int i = 0; i < 5; i++) {
            for (Jogador jogador : jogadores) {
                Cartas carta = baralho.daCarta();
                jogador.receberCarta(carta);
            }
        }
    }

    public void jogarRodada() {// método base para que utiliza os outros métodos para formar a estrutura base
                               // do jogo
        if (jogadores.size() < 5) {
            System.out.println("Não há jogadores suficientes para jogar uma rodada de poker.");
            return;
        }

        baralho.embaralha();
        distribuirCartas();
        fazerApostas();

        if (jogadores.size() < 2) {
            System.out.println("A rodada terminou. Não há jogadores suficientes para continuar.");
            definirVencedor();
            return;
        }

        rodadaTroca();

        fazerApostas();

        if (jogadores.size() < 2) {
            System.out.println("A rodada terminou. Não há jogadores suficientes para continuar.");
            definirVencedor();
            return;
        }

        mostrarCartas();
        System.out.println("");

        definirVencedor();

        distribuirPote();

        limparMaosEPote();

        // Check if enough players remaining to continue the game
        if (jogadores.size() < 2) {
            System.out.println("O jogo terminou. Não há jogadores suficientes para continuar.");
        }
    }

    private void rodadaTroca() {
        for (Jogador jogador : jogadores) {
            if (jogador.getNome().equals("SeuNome")) { // Verifica se o jogador é o usuário
                jogador.pedirTroca(baralho.getCartas());
            } else {
                jogador.escolherCartasTrocaAleatoriamente(baralho.getCartas());
            }
        }
    }

    private void fazerApostas() {// método que inicia as apostas com a principal lógica por tras
        int currentPlayerIndex = (BB + 1) % jogadores.size();
        boolean allPlayersDone = false;

        while (!allPlayersDone) {
            Jogador currentPlayer = jogadores.get(currentPlayerIndex);

            if (currentPlayer == jogadores.get(0)) {
                System.out.println("Jogador: " + currentPlayer.getNome());
                currentPlayer.mostrarMao();

                int acao = obterEscolhaUsuario();

                switch (acao) {
                    case 1:
                        currentPlayer.apostar(apostaAtual);
                        pot += apostaAtual;
                        break;
                    case 2:
                        int novaAposta = obterNovaApostaUsuario();
                        currentPlayer.apostar(novaAposta);
                        apostaAtual = novaAposta;
                        pot += novaAposta;
                        break;
                    case 3:
                        jogadoresInativos.add(currentPlayer);
                        jogadores.remove(currentPlayer);
                        if (currentPlayerIndex < BB) {
                            BB--;
                        }
                        System.out.println(currentPlayer.getNome() + " desistiu: ");
                        System.out.println("");
                        break;
                    default:
                        System.out.println("Escolha inválida. Completando a aposta.");
                        currentPlayer.apostar(apostaAtual);
                        pot += apostaAtual;
                        System.out.println("");
                        break;
                }
            } else {
                System.out.println(currentPlayer.getNome() + " :");
                System.out.println("");
                int acao = fazerEscolhaAleatoria();

                switch (acao) {
                    case 1:
                        currentPlayer.apostar(apostaAtual);
                        pot += apostaAtual;
                        break;
                    case 2:
                        int novaAposta = apostaAtual + new Random().nextInt(50) + 1;
                        currentPlayer.apostar(novaAposta);
                        apostaAtual = novaAposta;
                        pot += novaAposta;
                        break;
                    case 3:
                        jogadoresInativos.add(currentPlayer);
                        jogadores.remove(currentPlayer);
                        if (currentPlayerIndex < BB) {
                            BB--;
                        }
                        System.out.println(currentPlayer.getNome() + " desistiu: ");
                        System.out.println("");
                        break;
                    default:
                        System.out.println("Escolha inválida. Completando a aposta.");
                        currentPlayer.apostar(apostaAtual);
                        pot += apostaAtual;
                        System.out.println("");
                        break;
                }
            }

            if (jogadores.size() == 1 || currentPlayerIndex == BB) {
                allPlayersDone = true;
            } else {
                currentPlayerIndex = (currentPlayerIndex + 1) % jogadores.size();
            }
        }
    }

    private int obterEscolhaUsuario() {
        System.out.println("Escolha sua ação:\n1. Completar\n2. Aumentar a aposta\n3. Desistir");

        int escolha = Teclado.leInt();

        while (escolha < 1 || escolha > 3) {
            System.out.println("Escolha inválida. Por favor, selecione uma opção válida:");
            escolha = Teclado.leInt();
        }

        return escolha;
    }

    private int obterNovaApostaUsuario() {
        System.out.println("Informe o valor da nova aposta:");

        int novaAposta = Teclado.leInt();

        while (novaAposta <= apostaAtual) {
            System.out.println("Aposta inválida. O valor da nova aposta deve ser maior que a aposta atual:");
            novaAposta = Teclado.leInt();
        }

        return novaAposta;
    }

    private int fazerEscolhaAleatoria() {
        return new Random().nextInt(3) + 1; // Gera um número aleatório entre 1 e 3
    }

    private void mostrarCartas() { // mostra as cartas de todos jogadores no final da rodada
        for (Jogador jogador : jogadores) {
            jogador.mostrarMao();

        }
    }

    private void definirVencedor() {
        Jogador vencedor = jogadores.get(0); // Inicialmente, o primeiro jogador é considerado o vencedor
        int empate = 0;

        for (int i = 1; i < jogadores.size(); i++) {
            Jogador jogadorAtual = jogadores.get(i);

            if (jogadorAtual.getForcaMao() > vencedor.getForcaMao()) {
                vencedor = jogadorAtual;
            } else if (jogadorAtual.getForcaMao() == vencedor.getForcaMao()) {
                // Em caso de empate na força da mão, consideramos a carta mais alta
                if (jogadorAtual.getCartaMaisAlta().getValor() > vencedor.getCartaMaisAlta().getValor()) {
                    vencedor = jogadorAtual;
                } else if (jogadorAtual.getCartaMaisAlta().getValor() == vencedor.getCartaMaisAlta().getValor()) {
                    empate = 1; // Em caso de empate também na carta mais alta, consideramos o desempate pelo
                                // naipe
                }
            }
        }

        if (empate == 0) {
            System.out.print("");
            vencedor.receberFichas(pot);
            System.out.println("O vencedor é: " + vencedor.getNome());
            System.out.println(
                    "O vencedor é: " + vencedor.getNome() + ". Fichas restantes: " + vencedor.getQuantFichas());

        } else {
            System.out.print("");
            System.out.println("Não houve vencedores pois ocorreu um empate em todos os parâmetros!");
            for (Jogador jogador : jogadores) {
                jogador.receberFichas(pot / jogadores.size());
                if (!jogadoresInativos.contains(jogador)) {
                    jogador.limparMao();
                }
            }
        }
    }

    private void distribuirPote() {
        for (Jogador jogador : jogadores) {
            jogador.receberFichas(pot / jogadores.size());
        }
    }

    private void limparMaosEPote() {// limpar a mão e o pote da
        for (Jogador jogador : jogadores) {
            jogador.limparMao();
        }
        pot = 0;
        apostaAtual = 10; // Valor inicial do big blind
        BB = (BB + 1) % jogadores.size();
        SB = (BB + 3) % jogadores.size();
    }

    public void adicionarJogadorInativo(Jogador jogador) {
        jogadoresInativos.add(jogador);
    }

    public static void main(String[] args) {// método main que inicia o jogo
        PokerGame jogo = new PokerGame();
        Jogador usuario = new Jogador("SeuNome", 200);
        jogo.adicionarJogador(usuario);
        jogo.adicionarJogador(new Jogador("Twisted Fate", 200));
        jogo.adicionarJogador(new Jogador("Neymar", 200));
        jogo.adicionarJogador(new Jogador("Bluezao", 200));
        jogo.adicionarJogador(new Jogador("Valeci", 200));

        jogo.jogarRodada();
        boolean continuar = true;

        do {
            jogo.jogarRodada();

            if (jogo.jogadores.size() < 2) {
                System.out.println("O jogo terminou. Não há jogadores suficientes para continuar.");
                break;
            }

            System.out.println("Deseja continuar jogando? (s/n)");
            String escolha = Teclado.leString();

            if (escolha.equalsIgnoreCase("n")) {
                continuar = false;
            } else {
                // Adicionar de volta os jogadores que desistiram na primeira rodada
                for (Jogador jogador : jogo.jogadoresInativos) {
                    jogo.adicionarJogador(jogador);
                }
                jogo.jogadoresInativos.clear();
            }
        } while (continuar);
    }
}
