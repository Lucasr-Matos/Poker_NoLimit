import java.util.ArrayList;
import java.util.List;
//importações
import java.util.Random;

public class Jogador {
    private String nome;
    private List<Cartas> mao;
    private int quantFichas;
    private int aposta;
    private int forcaMao;
    // atributos da classe

    public Jogador(String nome, int quantquantFichas) {// construtor da classe
        this.nome = nome;
        this.mao = new ArrayList<>();
        this.quantFichas = quantquantFichas;
        aposta = 0;
        forcaMao = 0;
    }

    public int getAposta() {
        return aposta;
    }

    public String getNome() {
        return nome;
    }

    public int getQuantFichas() {
        return quantFichas;
    }

    public int getForcaMao() {
        return forcaMao;
    }

    // métodos getter and setter

    public void receberCarta(Cartas carta) {
        mao.add(carta);// método para adicionar cartas na mão do jogador
    }

    public void definirTipoJogo() {
        // Ordenar as cartas em ordem crescente (usando Bubble Sort)
        int n = mao.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                Cartas cartaAtual = mao.get(j);
                Cartas proximaCarta = mao.get(j + 1);
                if (cartaAtual.getValor() > proximaCarta.getValor()) {
                    // Trocar as cartas de posição
                    mao.set(j, proximaCarta);
                    mao.set(j + 1, cartaAtual);
                }
            }
        }

        // Verificar se é um Royal Flush
        boolean isRoyalFlush = mao.get(0).getValor() == 10 && isStraightFlush();
        if (isRoyalFlush) {
            forcaMao = 22;
            return;
        }

        // Verificar se é um Straight Flush
        boolean isStraightFlush = isStraightFlush();
        if (isStraightFlush) {
            forcaMao = 21;
            return;
        }

        // Verificar se é uma Quadra
        boolean isQuadra = isQuadra();
        if (isQuadra) {
            forcaMao = 20;
            return;
        }

        // Verificar se é um Full House
        boolean isFullHouse = isFullHouse();
        if (isFullHouse) {
            forcaMao = 19;
            return;
        }

        // Verificar se é um Flush
        boolean isFlush = isFlush();
        if (isFlush) {
            forcaMao = 18;
            return;
        }

        // Verificar se é um Straight
        boolean isStraight = isStraight();
        if (isStraight) {
            forcaMao = 17;
            return;
        }

        // Verificar se é uma Trinca
        boolean isTrinca = isTrinca();
        if (isTrinca) {
            forcaMao = 16;
            return;
        }

        // Verificar se são Dois Pares
        boolean isDoisPares = isDoisPares();
        if (isDoisPares) {
            forcaMao = 15;
            return;
        }

        // Verificar se é um Par
        boolean isPar = isPar();
        if (isPar) {
            forcaMao = 14;
            return;
        }

        // Nenhum tipo de jogo específico (Cartas mais alta)
        forcaMao = mao.get(4).getValor();
    }

    private boolean isStraightFlush() {
        return isStraight() && isFlush();
    }

    private boolean isQuadra() {
        int count = 1;
        for (int i = 0; i < mao.size() - 1; i++) {
            if (mao.get(i).getValor() == mao.get(i + 1).getValor()) {
                count++;
                if (count == 4) {
                    return true;
                }
            } else {
                count = 1;
            }
        }
        return false;
    }

    private boolean isFullHouse() {
        boolean isTrinca = false;
        boolean isPar = false;

        for (int i = 0; i < mao.size() - 2; i++) {
            if (mao.get(i).getValor() == mao.get(i + 1).getValor()
                    && mao.get(i).getValor() == mao.get(i + 2).getValor()) {
                isTrinca = true;
            }
        }

        for (int i = 0; i < mao.size() - 1; i++) {
            if (mao.get(i).getValor() == mao.get(i + 1).getValor()) {
                if (!isTrinca) {
                    isPar = true;
                } else {
                    isPar = false;
                }
            }
        }

        return isTrinca && isPar;
    }

    private boolean isFlush() {
        return mao.get(0).getNaipe() == mao.get(1).getNaipe() &&
                mao.get(0).getNaipe() == mao.get(2).getNaipe() &&
                mao.get(0).getNaipe() == mao.get(3).getNaipe() &&
                mao.get(0).getNaipe() == mao.get(4).getNaipe();
    }

    private boolean isStraight() {
        int firstValue = mao.get(0).getValor();
        int lastValue = mao.get(mao.size() - 1).getValor();
        return lastValue - firstValue == 4;
    }

    private boolean isTrinca() {
        for (int i = 0; i < mao.size() - 2; i++) {
            if (mao.get(i).getValor() == mao.get(i + 1).getValor()
                    && mao.get(i).getValor() == mao.get(i + 2).getValor()) {
                return true;
            }
        }
        return false;
    }

    private boolean isDoisPares() {
        int countPairs = 0;
        for (int i = 0; i < mao.size() - 1; i++) {
            if (mao.get(i).getValor() == mao.get(i + 1).getValor()) {
                countPairs++;
                i++;
            }
        }
        return countPairs == 2;
    }

    private boolean isPar() {
        for (int i = 0; i < mao.size() - 1; i++) {
            if (mao.get(i).getValor() == mao.get(i + 1).getValor()) {
                return true;
            }
        }
        return false;
    }

    public Cartas getCartaMaisAlta() {
        return mao.get(4);
    }

    public void mostrarMao() {
        System.out.println(nome + ":");
        for (Cartas carta : mao) {
            System.out.println(carta);
        }
    }

    public void pedirTroca(List<Cartas> baralho) {// método que faz o funcionamento da troca dentro do método rodada
                                                  // troca na classe controle
        // Solicitar as cartas para troca ao jogador
        System.out.println(getNome() + " selecione as cartas que deseja trocar (digite o número correspondente):");

        for (int i = 0; i < mao.size(); i++) {
            System.out.println((i + 1) + ". " + mao.get(i));
        }

        System.out.println("Digite 0 para não trocar nenhuma carta.");

        List<Integer> cartasParaTrocar = new ArrayList<>();

        int opcao = 0;
        for (int i = 0; i < 5; i++) {
            opcao = Teclado.leInt();

            if (opcao < 0 || opcao > mao.size()) {
                System.out.println("Opção inválida. Digite novamente.");
            } else if (opcao != 0) {
                cartasParaTrocar.add(opcao - 1);

            } else if (opcao == 0) {
                break;
            }
        }

        // Trocar as cartas selecionadas pelo jogador
        for (int indice : cartasParaTrocar) {
            Cartas cartaTrocada = mao.get(indice);
            Cartas novaCarta = baralho.remove(0); // Remover a primeira carta do baralho
            mao.set(indice, novaCarta);
            baralho.add(cartaTrocada); // Adicionar a carta trocada de volta ao baralho
        }
        if (getNome().equals("SeuNome")) { // Verifica se o jogador é o usuário
            mostrarMao();
            System.out.println("");
        }
    }

    public void escolherCartasTrocaAleatoriamente(List<Cartas> baralho) {
        Random random = new Random();

        boolean trocarCartas = random.nextBoolean();

        if (trocarCartas) {
            int numCartasTroca = random.nextInt(3) + 1;
            List<Integer> cartasParaTrocar = new ArrayList<>();

            while (cartasParaTrocar.size() < numCartasTroca) {
                int indice = random.nextInt(mao.size());
                if (!cartasParaTrocar.contains(indice)) {
                    cartasParaTrocar.add(indice);
                }
            }

            for (int indice : cartasParaTrocar) {
                Cartas cartaTrocada = mao.get(indice);
                Cartas novaCarta = baralho.remove(0); // Remover a primeira carta do baralho
                mao.set(indice, novaCarta);
                baralho.add(cartaTrocada); // Adicionar a carta trocada de volta ao baralho
            }
        }

        mostrarMao();
        System.out.println("");
    }

    public boolean podeApostar(int valorAposta) {// verifica se o jogador pode apostar
        return quantFichas >= valorAposta;
    }

    public void apostar(int valor) { // método para apostas
        if (valor > quantFichas) {
            System.out.println("Não há fichas suficientes para fazer essa aposta.");
            System.out.println("");
            return;
        }

        quantFichas -= valor;
        aposta += valor;
        System.out.println(nome + " fez uma aposta de " + valor + " fichas.");
        System.out.println("");

    }

    public void receberFichas(int quantidade) { // método para receber fichas
        quantFichas += quantidade;
    }

    public void limparMao() {// método para limpar a mão
        mao.clear();
    }

}