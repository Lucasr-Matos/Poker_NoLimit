public class Cartas {
    private int valor;
    private String naipe;//atributos

    public Cartas(int valor, String naipe) {
        this.valor = valor;
        this.naipe = naipe;
    }// construtor

    public int getValor() {
        return valor;
    }

    public String getNaipe() {
        return naipe;
    }

    @Override
    public String toString() {
        return valor + " de " + naipe;
    }
    //getter and setter
}