import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

//importações para funcionamento dos métodos

public class Baralho {
    private List<Cartas> cartas;
    private int topo;
    // atributos

    public Baralho() {// constutor (cria a estrutura base para o baralho)
        cartas = new ArrayList<>();
        topo = 0;

        // Adicionando cartas normais
        String[] naipes = { "Paus", "Ouros", "Copas", "Espadas" };
        int[] valor = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };

        for (String naipe : naipes) {
            for (int nome : valor) {
                Cartas carta = new Cartas(nome, naipe);
                cartas.add(carta);
            }
        }
    }

    public void embaralha() {// método para embaralhar as cartas
        Random random = new Random();
        Collections.shuffle(cartas, random);
    }

    public Cartas daCarta() {// método para dar cartas (Não esta sendo utilizado)
        if (topo < cartas.size()) {
            Cartas carta = cartas.get(topo);
            topo++;
            return carta;
        } else {
            return null;
        }
    }

    public boolean temCarta() {
        return topo < cartas.size();
    }

    public void imprimeBaralho() {// método para imprimir o baralho (utilizado somente para testes)
        for (Cartas carta : cartas) {
            System.out.println(carta.getValor() + " de " + carta.getNaipe());
        }
    }

    public List<Cartas> getCartas() {// método para retornar uma lista de cartas
        embaralha();
        return cartas;
    }
}